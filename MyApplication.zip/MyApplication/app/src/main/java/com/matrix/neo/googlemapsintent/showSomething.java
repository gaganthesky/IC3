package com.matrix.neo.googlemapsintent;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by neo on 11/04/15.
 */
public class showSomething extends Activity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.something_else);
    }
}

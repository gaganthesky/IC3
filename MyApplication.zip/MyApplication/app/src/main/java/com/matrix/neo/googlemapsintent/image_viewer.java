package com.matrix.neo.googlemapsintent;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by neo on 11/04/15.
 */
public class image_viewer extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.image_layout);
    }

}
